﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using System;

public class UIController : MonoBehaviour
{
    public Transform infoPanel;
    public GameObject objects;
    public GameObject demoscript;
    public Text  numberColiisionText,destroyText;
    public InputField numberObjectText;
    public Button create;
    public int numberObject;

    private void Start()
    {

        SetCollisionCount(GameController.gameController.numberCollisionCount);
        SetObjectNumberCount(GameController.gameController.numberObject);
        SetDestroyingCount(GameController.gameController.numberOfDestroying);
    }

    
    public void SetCollisionCount(int aNumber)
    {
        numberColiisionText.text = aNumber.ToString();
    }

    
    public void SetDestroyingCount(int aNumber)
    {
        destroyText.text = aNumber.ToString();
    }
    public void SetObjectNumberCount(int aNumber)
    {
       
        demoscript=GameObject.FindGameObjectWithTag("Script");
        demoscript.GetComponent<StartingManager>().NumberOfBodies = aNumber;
       
    }

    public void GetInput()
    {
        numberObject = Convert.ToInt32(numberObjectText.text);
        demoscript = GameObject.FindGameObjectWithTag("Script");
        demoscript.GetComponent<StartingManager>().NumberOfBodies = numberObject;
    }
}
