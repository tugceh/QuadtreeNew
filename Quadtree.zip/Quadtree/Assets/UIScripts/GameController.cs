﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public static GameController gameController;
    public int numberCollisionCount=0,numberObject,numberOfDestroying;
    public InputField numberObjectText;

    private void Awake()
    {
        if (GameController.gameController == null)
        {
            GameController.gameController = this;
        }
        else
        {
            if (this != GameController.gameController)
            {
                Destroy(this.gameObject);
            }
        }
        DontDestroyOnLoad(GameController.gameController.gameObject);
    }

    #region Collision
    public void IncreaseCollisionCount()
    {
        
        numberCollisionCount++;
        SetCollisionCountVisual();
    }
    public void SetCollisionCount(int aNumber)
    {
        numberCollisionCount = aNumber;
        SetCollisionCountVisual();
    }
    private void SetCollisionCountVisual()
    {
        GameObject userInterface = GameObject.FindGameObjectWithTag("UserInterface");
        userInterface.GetComponent<UIController>().SetCollisionCount(numberCollisionCount);
    }
    public int GetCollisionCount()
    {
        return numberCollisionCount;
    }
    #endregion
    #region Destroying
    public void IncreaseDestroyingCount()
    {

        numberOfDestroying++;
        SetDestroyingCountVisual();
    }
    public void SetDestroyingCount(int aNumber)
    {
        numberOfDestroying = aNumber;
        SetDestroyingCountVisual();
    }
    private void SetDestroyingCountVisual()
    {
        GameObject userInterface = GameObject.FindGameObjectWithTag("UserInterface");
        userInterface.GetComponent<UIController>().SetDestroyingCount(numberOfDestroying);
    }
    public int GetDestroyingCount()
    {
        return numberOfDestroying;
    }
    #endregion
    
    
    #region Objects
    public void GetInput(string objectNum)
    {
        numberObject =Convert.ToInt32( numberObjectText.text);
        GameObject myInterface = GameObject.FindGameObjectWithTag("UserInterface");
        myInterface.GetComponent<UIController>().SetObjectNumberCount(numberObject);
    }
    #endregion
}
