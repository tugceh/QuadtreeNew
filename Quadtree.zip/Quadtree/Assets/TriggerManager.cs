﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerManager : MonoBehaviour
{
    [Header("Controlling Life")]
    public int life;

    bool Die = false;



    private void OnTriggerEnter(Collider other)
    {
        //Enter tag in Clone Objects. But Main Object dont have any tag
        if (other.tag == "Player")
        {
            other.GetComponent<CreateObjectsBodyManager>().life--;

            GameController.gameController.IncreaseCollisionCount(); //Increase collision count in UI

            life = other.GetComponent<CreateObjectsBodyManager>().life;

            if (life == 0)
            {

                other.gameObject.SetActive(false); //Hide died objects
                Die = true;

                GameController.gameController.IncreaseDestroyingCount(); //Increase Destroying Count in UI

                //Destroy(this.gameObject);

                if (Die == true)
                {
                    //Instantiate new objects substituted for died objects
                    GameObject.FindGameObjectWithTag("Script").GetComponent<StartingManager>().InstObj();

                }

            }
            
        }
    }
}
