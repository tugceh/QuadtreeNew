﻿

public enum CollisionType
{

    // First frame of collision
    Enter,


    // Collision occuring over multiple frames
    Stay,


    // First frame collision is no longer occuring
    Exit
}

