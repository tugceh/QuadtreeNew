﻿using UnityEngine;


public sealed class CollisionTest
{

    //Fields

    private static Vector3[] Normals =
    {
            // x
            new Vector3(-1, 0, 0),
            new Vector3(1, 0, 0),
            // z
            new Vector3(0, 0, -1),
            new Vector3(0, 0, 1),
            // y
            new Vector3(0, -1, 0),
            new Vector3(0, 1, 0),
        };

    private static float[] distances = new float[6];

    //Public methods

    public static bool Test(Vector3 min0, Vector3 max0, Vector3 min1, Vector3 max1, ref CollisionResult result, bool twod = true)
    {
        distances[0] = max1[0] - min0[0];
        distances[1] = max0[0] - min1[0];
        distances[2] = max1[2] - min0[2];
        distances[3] = max0[2] - min1[2];

        var iteration = 4;


        if (!twod)
        {
            distances[4] = max1[1] - min0[1];
            distances[5] = max0[1] - min1[1];
            iteration = 6;
        }

        for (int i = 0; i < iteration; i++)
        {
            if (distances[i] < 0.0f)
                return false;

            if ((i == 0) || distances[i] < result.Penetration)
            {
                result.Penetration = distances[i];
                result.Normal = Normals[i];
            }
        }

        return true;
    }


    //Test if a finite line segment intersects a collider
    public static bool SegmentIntersects(ICollisionShape collider, Vector3 start, Vector3 end)
    {
        Vector3 d = (end - start) * 0.5f;
        Vector3 e = (collider.Max - collider.Min) * 0.5f;
        Vector3 c = start + d - (collider.Min + collider.Max) * 0.5f;

        Vector3 ad = new Vector3(Mathf.Abs(d.x), Mathf.Abs(d.y), Mathf.Abs(d.z));

        if (Mathf.Abs(c.x) > e.x + ad.x)
            return false;
        if (Mathf.Abs(c.y) > e.y + ad.y)
            return false;
        if (Mathf.Abs(c.z) > e.z + ad.z)
            return false;

        if (Mathf.Abs(d.y * c.z - d.z * c.y) > e.y * ad.z + e.z * ad.y + Mathf.Epsilon)
            return false;
        if (Mathf.Abs(d.z * c.x - d.x * c.z) > e.z * ad.x + e.x * ad.z + Mathf.Epsilon)
            return false;
        if (Mathf.Abs(d.x * c.y - d.y * c.x) > e.x * ad.y + e.y * ad.x + Mathf.Epsilon)
            return false;

        return true;
    }

}


