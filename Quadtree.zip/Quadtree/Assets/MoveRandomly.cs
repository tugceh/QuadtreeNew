﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Experimental.PlayerLoop;

public class MoveRandomly : MonoBehaviour
{
    /*public Rigidbody rb;
    public float accelerationTime = 0.1f;
    public float maxSpeed = 5f;
    private Vector3 movement;
    private float timeLeft;

    private void Update()
    {
        timeLeft -= Time.deltaTime;
        if (timeLeft <=0)
        {
            movement = new Vector3(Random.Range(0.05f,0.1f),0,Random.Range(0.05f, 0.1f));
            timeLeft += accelerationTime;
        }
    }

    private void FixedUpdate()
    {
        rb.AddForce(movement * maxSpeed);
    }*/

    public GameObject[] wayPoints;
    int current = 0;
    float rotSpeed;
    public float speed;
    float WPradius = 1;
    private void Update()
    {
        if (Vector3.Distance(wayPoints[current].transform.position,transform.position) < WPradius)
        {
            current = Random.Range(0,wayPoints.Length);
            if (current >= wayPoints.Length)
            {
                current = 0;
            }
        }
        transform.position = Vector3.MoveTowards(transform.position,wayPoints[current].transform.position, Time.deltaTime * speed);
    }
}
