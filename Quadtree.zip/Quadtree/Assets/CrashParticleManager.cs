﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrashParticleManager : MonoBehaviour
{
    public Transform sparkle;

    private void Start()
    {
        sparkle.GetComponent<ParticleSystem>().enableEmission = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        sparkle.GetComponent<ParticleSystem>().enableEmission = true;
        StartCoroutine(stopSparkles());
    }

    IEnumerator stopSparkles()
    {
        yield return new WaitForSeconds(.4f);

        sparkle.GetComponent<ParticleSystem>().enableEmission = false;
    }
}
