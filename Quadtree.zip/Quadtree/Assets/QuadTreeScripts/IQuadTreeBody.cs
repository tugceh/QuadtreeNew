﻿using UnityEngine;


public interface IQuadTreeBody
{
    Vector2 Position { get; }
    bool QuadTreeIgnore { get; }
}


