﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class QuadTree
{

    private static class PoollingQuadTree
    {

        //Fields

        private static Queue<QuadTree> poolingQuadTree;
        private static int maxPool = 1024;
        private static int defaultMaxObjectsNode = 6;
        private static int defaultMaxLevel = 6;



        // Methods

        //Controlling quadtree havent be formed
        public static QuadTree GetQuadTree(Rect rects, QuadTree parent)
        {
            if (poolingQuadTree == null)
                Init();
            QuadTree tree = null;
            if (poolingQuadTree.Count > 0)
            {
                tree = poolingQuadTree.Dequeue();
                tree._rects = rects;
                tree._parent = parent;
                tree._maxLevel = parent._maxLevel;
                tree._maxObjectsNode = parent._maxObjectsNode;
                tree._currentLevel = parent._currentLevel + 1;
            }
            else
                tree = new QuadTree(rects, parent);
            return tree;
        }

        //creating trees
        public static void PoolQuadTree(QuadTree tree)
        {
            if (tree == null)
                return;
            tree.Clear();
            if (poolingQuadTree.Count > maxPool)
                return;
            poolingQuadTree.Enqueue(tree);
        }
        //Initialization quadtree
        private static void Init()
        {
            poolingQuadTree = new Queue<QuadTree>();
            for (int i = 0; i < maxPool; i++)
            {
                poolingQuadTree.Enqueue(new QuadTree(Rect.zero, defaultMaxObjectsNode, defaultMaxLevel));
            }
        }
    }

    // Constructors

    public QuadTree(Rect rects, int maxObjectsNode = 6, int maxLevel = 6)
    {
        _rects = rects;
        _maxObjectsNode = maxObjectsNode;
        _maxLevel = maxLevel;
        _bodies = new List<IQuadTreeBody>(maxObjectsNode);
    }

    private QuadTree(Rect bounds, QuadTree parent)
        : this(bounds, parent._maxObjectsNode, parent._maxLevel)
    {
        _parent = parent;
        _currentLevel = parent._currentLevel + 1;
    }

    // Fields

    private QuadTree _parent;
    private Rect _rects;
    private List<IQuadTreeBody> _bodies;
    private int _maxObjectsNode;
    private int _maxLevel;
    private int _currentLevel;
    private QuadTree _childA;
    private QuadTree _childB;
    private QuadTree _childC;
    private QuadTree _childD;
    private List<IQuadTreeBody> _Cache;

    // Methods

    //Adding quaftree
    public void AddBody(IQuadTreeBody body)
    {
        if (_childA != null)
        {
            var child = GetQuadrant(body.Position);
            child.AddBody(body);
        }
        else
        {
            _bodies.Add(body);
            if (_bodies.Count > _maxObjectsNode && _currentLevel < _maxLevel)
            {
                Split();
            }
        }
    }

    public List<IQuadTreeBody> GetBodies(Vector3 point, float radius)
    {
        var p = new Vector2(point.x, point.z);
        return GetBodies(p, radius);
    }

    public List<IQuadTreeBody> GetBodies(Vector2 point, float radius)
    {
        if (_Cache == null)
            _Cache = new List<IQuadTreeBody>(64);
        else
            _Cache.Clear();
        GetBodies(point, radius, _Cache);
        return _Cache;
    }

    public List<IQuadTreeBody> GetBodies(Rect rect)
    {
        if (_Cache == null)
            _Cache = new List<IQuadTreeBody>(64);
        else
            _Cache.Clear();

        GetBodies(rect, _Cache);
        return _Cache;
    }

    private void GetBodies(Vector2 point, float radius, List<IQuadTreeBody> bodies)
    {
        //no children
        if (_childA == null)
        {
            for (int i = 0; i < _bodies.Count; i++)
                bodies.Add(_bodies[i]);
        }
        else
        {
            if (_childA.ContainsCircle(point, radius))
                _childA.GetBodies(point, radius, bodies);
            if (_childB.ContainsCircle(point, radius))
                _childB.GetBodies(point, radius, bodies);
            if (_childC.ContainsCircle(point, radius))
                _childC.GetBodies(point, radius, bodies);
            if (_childD.ContainsCircle(point, radius))
                _childD.GetBodies(point, radius, bodies);
        }
    }

    private void GetBodies(Rect rect, List<IQuadTreeBody> bodies)
    {
        //no children
        if (_childA == null)
        {
            for (int i = 0; i < _bodies.Count; i++)
                bodies.Add(_bodies[i]);
        }
        else
        {
            if (_childA.ContainsRect(rect))
                _childA.GetBodies(rect, bodies);
            if (_childB.ContainsRect(rect))
                _childB.GetBodies(rect, bodies);
            if (_childC.ContainsRect(rect))
                _childC.GetBodies(rect, bodies);
            if (_childD.ContainsRect(rect))
                _childD.GetBodies(rect, bodies);
        }
    }

    public bool ContainsCircle(Vector2 circleCenter, float radius)
    {
        var center = _rects.center;
        var dx = Math.Abs(circleCenter.x - center.x);
        var dy = Math.Abs(circleCenter.y - center.y);
        if (dx > (_rects.width / 2 + radius))
        {
            return false;

        }
        if (dy > (_rects.height / 2 + radius))
        {
            return false;
        }
        if (dx <= (_rects.width / 2))
        {
            return true;
        }
        if (dy <= (_rects.height / 2))
        {
            return true;
        }
        var cornerDist = Math.Pow((dx - _rects.width / 2), 2) + Math.Pow((dy - _rects.height / 2), 2);
        return cornerDist <= (radius * radius);
    }

    public bool ContainsRect(Rect rect)
    {
        return _rects.Overlaps(rect);
    }

    private QuadTree GetLowestChild(Vector2 point)
    {
        var a = this;
        while (a != null)
        {
            var newChild = a.GetQuadrant(point);
            if (newChild != null)
                a = newChild;
            else break;
        }
        return a;
    }

    public void Clear()
    {
        PoollingQuadTree.PoolQuadTree(_childA);
        PoollingQuadTree.PoolQuadTree(_childB);
        PoollingQuadTree.PoolQuadTree(_childC);
        PoollingQuadTree.PoolQuadTree(_childD);
        _childA = null;
        _childB = null;
        _childC = null;
        _childD = null;
        _bodies.Clear();
    }

    public void DrawGizmos()
    {
        //draw children
        if (_childA != null)
            _childA.DrawGizmos();
        if (_childB != null)
            _childB.DrawGizmos();
        if (_childC != null)
            _childC.DrawGizmos();
        if (_childD != null)
            _childD.DrawGizmos();

        //draw rect
        Gizmos.color = Color.cyan;
        var giz1 = new Vector3(_rects.position.x, 0.1f, _rects.position.y);
        var giz2 = new Vector3(giz1.x + _rects.width, 0.1f, giz1.z);
        var giz3 = new Vector3(giz1.x + _rects.width, 0.1f, giz1.z + _rects.height);
        var giz4 = new Vector3(giz1.x, 0.1f, giz1.z + _rects.height);
        Gizmos.DrawLine(giz1, giz2);
        Gizmos.DrawLine(giz2, giz3);
        Gizmos.DrawLine(giz3, giz4);
        Gizmos.DrawLine(giz4, giz1);
    }

    private void Split()
    {
        var hx = _rects.width / 2;
        var hz = _rects.height / 2;
        var sz = new Vector2(hx, hz);

        //split 1
        var Loc1 = _rects.position;
        var Rect1 = new Rect(Loc1, sz);
        //split 2
        var Loc2 = new Vector2(_rects.position.x + hx, _rects.position.y);
        var Rect2 = new Rect(Loc2, sz);
        //split 3
        var Loc3 = new Vector2(_rects.position.x + hx, _rects.position.y + hz);
        var Rect3 = new Rect(Loc3, sz);
        //split 4
        var Loc4 = new Vector2(_rects.position.x, _rects.position.y + hz);
        var Rect4 = new Rect(Loc4, sz);

        //assign QuadTrees
        _childA = PoollingQuadTree.GetQuadTree(Rect1, this);
        _childB = PoollingQuadTree.GetQuadTree(Rect2, this);
        _childC = PoollingQuadTree.GetQuadTree(Rect3, this);
        _childD = PoollingQuadTree.GetQuadTree(Rect4, this);

        for (int i = _bodies.Count - 1; i >= 0; i--)
        {
            var child = GetQuadrant(_bodies[i].Position);
            child.AddBody(_bodies[i]);
            _bodies.RemoveAt(i);
        }
    }

    private QuadTree GetQuadrant(Vector2 point)
    {
        if (_childA == null)
            return null;
        if (point.x > _rects.x + _rects.width / 2)
        {
            if (point.y > _rects.y + _rects.height / 2)
                return _childC;
            else
                return _childB;
        }
        else
        {
            if (point.y > _rects.y + _rects.height / 2)
                return _childD;
            return _childA;
        }
    }

}
