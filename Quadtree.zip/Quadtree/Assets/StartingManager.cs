﻿using System.Collections.Generic;
using UnityEngine;
using System.Collections;

public class StartingManager : MonoBehaviour
{

    public enum CollisionSystemType
    {
        QuadTree
    }


    
    public CreateObjectsBodyManager ObjectsBody;


    [Header("Collider System Fields")]
    public CollisionSystemType CollisionSystemTypes;
    public int NumberOfBodies = 10; //Number of Spawn Objects

    [Header("Quad Tree Fields")]
    public Vector2 WorldSize = new Vector2(80, 80);
    public int BodiesNode = 6;
    public int MaxSections = 6;


    public QuadTree quadTree;
    private List<IQuadTreeBody> QuadTreeBodies = new List<IQuadTreeBody>();
    private CollisionSystemQuadTree CollSysQuad;

    

    //Use Coroutine 
    IEnumerator Wait()
    {
        // suspend execution for 5 seconds
        yield return new WaitForSeconds(10);
        print("Wait " + Time.time);
    }

    //Player enter objects number in UI so, I use coroutine so that user can enter number of objects in 5 seconds. Because when I start program, start function is executed and enter in for loop until player enter objets number and then it never enter in for loop.

    private void Update()
    {

        switch (CollisionSystemTypes)
        {

            case CollisionSystemType.QuadTree:
                CollSysQuad.Step();
                break;
        }

        //If bodies can move, refreshing QuadTree each frame 

        quadTree.Clear();

        foreach (var item in QuadTreeBodies)
        {
            quadTree.AddBody(item); //Adding quadtree bodies in world
        }


    }

    private IEnumerator Start()
    {


        quadTree = new QuadTree(new Rect(0, 0, WorldSize.x, WorldSize.y), BodiesNode, MaxSections); //Create quadTree World

        CollSysQuad = new CollisionSystemQuadTree(quadTree);

        yield return StartCoroutine("Wait");
        StopAllCoroutines();

        //Creating objects in for loop
        for (int i = 0; i < NumberOfBodies; i++)
        {

            InstObj(); //Instantiate objects
           
        }


    }
    public void InstObj()
    {
        var objects = GameObject.Instantiate<CreateObjectsBodyManager>(ObjectsBody);

        objects.transform.position = new Vector3(Random.Range(0, WorldSize.x), 0, Random.Range(0, WorldSize.y));
        objects.life = 5;
        objects.tag = "Player";


        CollSysQuad.AddBody(objects);
        quadTree.AddBody(objects);  // adding objects in QuadTree
        QuadTreeBodies.Add(objects); // hiding bodies for refreshing the tree in update

    }



    private void OnDrawGizmos()
    {
        if (quadTree == null)
            return;
        quadTree.DrawGizmos(); //Draw quadtree gizmos()
    }

    
}
